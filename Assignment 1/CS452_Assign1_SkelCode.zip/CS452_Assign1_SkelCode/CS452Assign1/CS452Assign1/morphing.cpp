#include "stdafx.h"
#include "CS452Assign1.h"

// TODO: Declare global variables here

void Initialize()
{
	/* TODO: Initialize your global variables here.
	   You might also want to set the window bounds
	   using the setWindowBounds function which
	   has already been implemented.

	   This function is called before the program
	   enter the main event loop. */
}

void Render(int mouseX, int mouseY)
{
	/* TODO: Render images here. The coordinates of
	   mouse pointer are passed in as parameters.
	   Use the renderImage function which has
	   already been implemented to display an
	   image onto the screen.

	   This function is called once for each
	   iteration of the main event loop. */
}

void Destroy()
{
	// TODO: Free all allocated memory here.
	// For example, all FreeImage_Unload calls go here.
}